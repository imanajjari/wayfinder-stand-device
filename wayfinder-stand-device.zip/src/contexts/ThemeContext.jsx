// src\contexts\ThemeContext.jsx
import { createContext, useEffect, useState, useMemo, useCallback } from 'react';

export const ThemeContext = createContext();

const lightTheme = {
  background: "#f8f8f8",
  canvasBackground: "#ffffff",
  textPrimary: "#1a1a1a", // متن اصلی
  textSecondary: "#C1C1C1FF", // متن ثانویه
  textMuted: "#666666", // متن کم‌رنگ
  textHeader: "#000000", // متن هدر
  textLink: "#0066cc", // رنگ لینک
  modelColor: "#474D84",
  pointStart: "#008AFF",
  pointEnd: "#00FFAB",
};

const darkTheme = {
  background: "#10172A",
  canvasBackground: "#3A4147FF", // TODO : شروین این بخش رنگش رو تغییر بده و هر رنگی رو مد نظرت بود کد رنگیش رو بده بزارم رو پروژه 
  textPrimary: "#1A1A1AFF", // متن اصلی
  textSecondary: "#C1C1C1FF", // متن ثانویه
  textMuted: "#666666", // متن کم‌رنگ
  textHeader: "#000000", // متن هدر
  textLink: "#0066cc", // رنگ لینک
  modelColor: "#474D84",
  pointStart: "#008AFF",
  pointEnd: "#00FFAB",
};

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(null); // حالت اولیه بدون تم

  useEffect(() => {
    const saved = localStorage.getItem('app-theme');
    if (saved === 'light' || saved === 'dark') {
      setTheme(saved);
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(prefersDark ? 'dark' : 'light');
    }
  }, []);

  useEffect(() => {
    if (theme) {
      document.documentElement.setAttribute('data-theme', theme);
      localStorage.setItem('app-theme', theme);
    }
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  // Memoize theme colors to prevent recalculation
  const themeColors = useMemo(() => {
    return theme === 'light' ? lightTheme : darkTheme;
  }, [theme]);

  useEffect(() => {
    if (themeColors?.textPrimary) {
      document.documentElement.style.setProperty('--text-color', themeColors.textPrimary);
    }
  }, [themeColors]);

  // Memoize context value
  const contextValue = useMemo(() => ({
    theme,
    toggleTheme,
    colors: themeColors
  }), [theme, toggleTheme, themeColors]);

  if (!theme) return null; // یا loading spinner

  return (
    <ThemeContext.Provider value={contextValue}>
      {children}
    </ThemeContext.Provider>
  );
};
