import { createContext, useContext, useState } from "react";
import { findOnePath, findOnePathMulityfloorV2 } from "../services/pathService";
import { getStandData } from "../storage/floorStorage";
import { findFloorOfDestination } from "../lib/floorUtils";
import { getMyStand } from "../storage/floorStorage";
import { getCompanyData } from '../storage/companyStorage';

const PathContext = createContext();

export function PathProvider({ children }) {
  const [path, setPath] = useState(null);
  const [loading, setLoading] = useState(false);
  const [currentFloorNumber, setCurrentFloorNumber] = useState(null);
  const [currentStand, setCurrentStand] = useState(null);
  const [lastDestination, setLastDestination] = useState(null);

  const updateCurrentFloorNumber = (floorNumber) => {
    setCurrentFloorNumber(floorNumber);

    const standData = getStandData();
    const standOnFloor = standData?.stands.find(
      (s) => s.floorNum === floorNumber
    );
    // console.log("====================================");
    // console.log("floorNumber :", floorNumber);
    // console.log("standData :", standData.stands);
    // console.log("standOnFloor :", standOnFloor);
    // console.log("====================================");
    setCurrentStand(standOnFloor);
  };
  const updateDestination = (destination) => {
    console.log("====================================");
    console.log("updateDestination destination", destination);
    console.log("updateDestination currentFloorNumber", currentFloorNumber);
    console.log("====================================");
    setLastDestination(destination);
    navigateToDestination(destination, currentFloorNumber);
  };

  const navigateToDestination = async (destination, currentFloorNumber) => {
    console.log(
      "🚀 navigateToDestination called with destination:",
      destination
    );

    const startFloor = currentFloorNumber ?? 0;
    const endFloor = destination.floorNumber ?? 0;

    console.log(
      "🟩 currentFloorNumber:",
      currentFloorNumber,
      "startFloor:",
      startFloor,
      "endFloor:",
      endFloor
    );

    if (startFloor === endFloor) {
      console.log("✅ Floors are same, fetching path directly");
      await fetchPath(null, destination);
    } else {
      const currentStand = getCurrentStandPosition();
      console.log("====================================");
      console.log(" else currentStand :", currentStand);
      console.log("====================================");
      setPath({
        message: "Path posted",
        id: 18,
        path: [
          {
            x: currentStand.x / 100,
            y: currentStand.y / 100,
            z: currentStand.z
          }
        ],
        type: "path",
      });
      // روش دوم 
      // const currentStand = getCurrentStandPosition();
      // console.log('====================================');
      // console.log("currentStand :",currentStand);
      // console.log('====================================');
      // console.log("🎈 ");
      //           if (currentStand) {
      //             navigateToDestination({
      //               ...currentStand,
      //               floorNumber: currentFloorNumber
      //             },currentFloorNumber);
      //           }
      // markFloorChange(destination, startFloor, endFloor);
    }
  };

  // تابع برای رفرش مسیر قبلی
  const refreshLastDestination = async ({ currentFloorNumber }) => {
    if (lastDestination) {
      console.log("🔄 Refreshing last destination:", lastDestination);
      console.log("🔄 Refreshing last currentFloorNumber:", currentFloorNumber);

      // صبر کن تا طبقه تنظیم شود
      await new Promise((resolve) => {
        setCurrentFloorNumber(currentFloorNumber);
        setTimeout(resolve, 0); // صبر کوتاه تا رندر انجام شود
      });

      await navigateToDestination(lastDestination, currentFloorNumber);
    }
  };

  const getCurrentStandPosition = () => {
    const standData = getStandData();
    // console.log("====================================");
    // console.log("standData :", standData);
    // console.log("currentFloorNumber :", currentFloorNumber);

    // console.log("====================================");
    const standOnFloor = standData?.stands.find(
      (s) => s.floorNum === currentFloorNumber
    );

    if (standOnFloor) {
      return {
        x: standOnFloor.entrance.x,
        y: standOnFloor.entrance.y,
        z: 1,
        floorNumber: standOnFloor.floorNum,
        floorId: findFloorOfDestination(standOnFloor).floorId,
      };
    }

    return null;
  };

  const markFloorChange = (end, startFloor, endFloor) => {
    console.log("📢 markFloorChange", { startFloor, endFloor, end });
    setPath({
      type: "floor-change",
      direction: endFloor > startFloor ? "up" : "down",
      end,
      path: [
      ], // 👈 اضافه شد
    });
  };

  const fetchPath = async (start, end) => {
    setLoading(true);
    try {
      if (!start) {
        const standData = getStandData();
        const standOnCurrentFloor = standData?.stands.find(
          (s) => s.floorNum === currentFloorNumber
        );

        if (standOnCurrentFloor) {
          start = {
            x: standOnCurrentFloor.entrance.x,
            y: standOnCurrentFloor.entrance.y,
            z: 1,
          };
        } else {
          start = { x: 58, y: 185, z: 1 };
        }
      }

      const fixedStart = {
        x: start.x,
        y: start.y,
        z: start.z ?? 1,
      };

      const fixedEnd = {
        x: end.x,
        y: end.y,
        z: end.z ?? 1,
      };

      // گرفتن فقط floorId عددی:
      const floorId =
        typeof end.floorId === "object" ? end.floorId : end.floorId;
      const res = await findOnePath({
        start: fixedStart,
        end: fixedEnd,
        skip: 100,
        floorId,
      });
      const calibratedPath = res.path.map(([x, y]) => ({
        x: x / 100,
        y: y / 100,
        z: 0.8,
      }));

      setPath({ ...res, path: calibratedPath, type: "path" });
    } catch (err) {
      console.error("خطا در دریافت مسیر:", err);
      setPath(null);
    } finally {
      setLoading(false);
    }
  };

    const fetchPathV2 = async ({start, end}) => {
      console.log("🚀 fetchPathV2 called with:", { start, end });
      
    setLoading(true);
    const myStand = getMyStand();
    const companyData = getCompanyData();
    try {
      if (!start) {
        start = myStand.id;
      }

      const res = await findOnePathMulityfloorV2({
      start,
      end:end.id,
      userId: companyData?.id,
      skip: 100,
      });
      
      
        const normalized = normalizePathResponse(res);
    if (!normalized || normalized.paths.every(p => p.path.length === 0)) {
      throw new Error("مسیر یافت نشد");
    }

console.log('normalized: ',normalized);

    // اگر چند طبقه‌ای می‌خواهی نگه داری:
    setPath(normalized);
    } catch (err) {
      console.error("خطا در دریافت مسیر:", err);
      setPath(null);
    } finally {
      setLoading(false);
    }
  };

  // p می‌تونه [x,y] یا {x,y} باشه
const toMeters = (p) => {
  const x = (p?.x ?? p?.[0]);
  const y = (p?.y ?? p?.[1]);
  if (typeof x !== "number" || typeof y !== "number") {
    throw new Error("مختصات نامعتبر است");
  }
  return { x: x / 100, y: y / 100, z: 0.8 };
};

// خروجی API را به ساختار یکسان و قابل‌استفاده تبدیل می‌کند
const normalizePathResponse = (res) => {
  const data = res?.data ?? res; // اگر مستقیم برگشت
  const floors = data?.paths;
  if (!Array.isArray(floors) || floors.length === 0) return null;

  const paths = floors.map((f) => ({
    floorId: f.floorId,
    path: (f.path ?? []).map(toMeters),
  }));

  return {
    floorDiff: data?.floorDiff ?? 0,
    paths,               // [{ floorId, path:[{x,y,z}, ...] }, ...]
    type: "path",
  };
};

  return (
    <PathContext.Provider
      value={{
        path,
        fetchPath,
        markFloorChange,
        navigateToDestination,
        refreshLastDestination,
        loading,
        updateCurrentFloorNumber,
        currentFloorNumber,
        currentStand,
        getCurrentStandPosition,
        updateDestination,
        lastDestination,
        fetchPathV2
      }}
    >
      {children}
    </PathContext.Provider>
  );
}

export function usePath() {
  return useContext(PathContext);
}
