// src/storage/index.js
export * from './storageService';
export * from './companyStorage';