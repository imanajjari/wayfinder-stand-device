import { useEffect, useRef, useState } from 'react';
import { getFileUrl } from '../../services/fileService';
import { searchDestinationsByCategory } from '../../services/destinationService';
import { useSearchResults } from '../../contexts/SearchResultsContext';
import DestinationListModal from '../Modal/DestinationListModal';
import ServiceButton from '../buttons/ServiceButton';
import { BsShop } from "react-icons/bs";
import { usePath } from '../../contexts/PathContext';
import { useShopDetails } from '../../contexts/ShopDetailsContext';

export default function CategoriesPanel({ categories = [], maxVisible = 20 }) {
  const [modalOpen, setModalOpen] = useState(false);
  const containerRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);
  const { showResults } = useSearchResults();
  const { lastDestination } = usePath();
   const { showShopDetails } = useShopDetails();
  const handleMouseDown = (e) => {
    setIsDragging(true);
    setStartX(e.pageX - containerRef.current.offsetLeft);
    setScrollLeft(containerRef.current.scrollLeft);
  };


  const handleMouseLeave = () => setIsDragging(false);
  const handleMouseUp = () => setIsDragging(false);

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - containerRef.current.offsetLeft;
    const walk = (x - startX) * 1.5;
    containerRef.current.scrollLeft = scrollLeft - walk;
  };

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const handleScroll = () => {
      el.classList.add('scrolling');
      clearTimeout(el._scrollTimeout);
      el._scrollTimeout = setTimeout(() => {
        el.classList.remove('scrolling');
      }, 500);
    };

    el.addEventListener('scroll', handleScroll);
    return () => el.removeEventListener('scroll', handleScroll);
  }, []);

  const visible = categories.slice(0, maxVisible);
  const hidden = categories.slice(maxVisible);

  const handleCategoryClick = async (cat) => {
    try {
      const results = await searchDestinationsByCategory(cat.name);
      showResults(results.data, `دسته‌بندی: ${cat.name}`);
    } catch (err) {
      console.error(`❌ خطا در دریافت فروشگاه‌های دسته ${cat.name}:`, err);
      showResults([], `خطا در دریافت ${cat.name}`);
    }
  };

  return (
    <div>
      <div className='flex justify-between items-center'>


      <div
        ref={containerRef}
        className="flex gap-2 overflow-x-auto scrollbar-hidden transition-all duration-300 cursor-grab active:cursor-grabbing px-4"
        onMouseDown={handleMouseDown}
        onMouseLeave={handleMouseLeave}
        onMouseUp={handleMouseUp}
        onMouseMove={handleMouseMove}
        onWheel={(e) => {
          containerRef.current.scrollLeft += e.deltaY;
        }}
      >
        {visible.map((cat, i) => (
          <button
            key={i}
            onClick={() => handleCategoryClick(cat)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-[#10172A] rounded-2xl whitespace-normal break-words border border-gray-500 hover:bg-neutral-600 transition"
          >
            <img
              src={getFileUrl(cat.icon)}
              alt={cat.name}
              className="w-5 md:w-8 rounded-full object-cover"
            />
            <p className="text-base lg:text-lg ">{cat.name}</p>
          </button>
        ))}
              <ServiceButton />
        {hidden.length > 0 && (
          <button
            onClick={() => setModalOpen(true)}
            className="px-3 py-1 bg-neutral-600 rounded-full text-sm"
          >
            بیشتر...
          </button>
        )}
      </div>
  <div className=' px-2 border-r-2 border-neutral-400'>
    <button onClick={()=>{lastDestination&&showShopDetails(lastDestination)}} className={`flex rounded-xl p-2 border ${lastDestination?'bg-[#00FFAB] shadow-[0_0_30px_#00FFAA8D] text-black border-black':'bg-[#10172A]  border-[#828284] text-white'}`}>
      <p className='px-1 hidden sm:block'>
        مشاهده جزئیات فروشکاه
      </p>
        <BsShop className='text-xl'/>
    </button>
  </div>
      </div>
      <DestinationListModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title="سایر دسته‌بندی‌ها"
        destinations={hidden}
        onSelect={async (cat) => {
          try {
            const results = await searchDestinationsByCategory(cat.name);
            showResults(results.data, `دسته‌بندی: ${cat.name}`);
            setModalOpen(false); // بستن مودال دسته‌بندی‌ها
          } catch (err) {
            console.error(`❌ خطا در دریافت فروشگاه‌های دسته ${cat.name}:`, err);
            showResults([], `خطا در دریافت ${cat.name}`);
            setModalOpen(false);
          }
        }}
      />
    </div>
  );
}
